<div class="text-center col-md-offset-1 col-md-2 positionsidebar">
    <h4 class="titreSidebar blue">Panel D'administration </h4>
    <ul>
        <li> <a href="#"><p>Ajout de billet Jeux </p></a></li>
        <li> <a href="#"><p>Ajout de billet Discussion</p></a></li>
        <li> <a href="#" id="moderation"><p>Modération commentaire</p></a></li>
        <li> <a href="#"><p>Ajout de Miniature</p></a></li>
    </ul>
</div>
