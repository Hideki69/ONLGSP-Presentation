<div class="img-panel text-center col-md-10 col-md-offset-1">
    <div class="row">
        <h2> Profitez de notre Panel d'administration</h2>
        <img class="col-md-6 col-md-offset-3 img-responsive"  src="images/panel.png">
    </div>
</div>
</main>
