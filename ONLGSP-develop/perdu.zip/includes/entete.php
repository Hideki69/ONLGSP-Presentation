<?php
session_start();//toujour en haut

include'includes/connexion.php';
?>

<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="Content-Language" content="fr" />
        <meta name="description" content="Une description de la page..." />
        <meta name="keywords" content="Game, Serveur, Linux, Noob, Provider" />
        <meta name|http-equiv="Mot-clé" content="Game, Serveur, Linux, Noob, Provider" />

        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=0.5, maximum-scale=3.0, user-scalable=yes, shrink-to-fit=no">

        <title> Open Noob Linux Game Server Provider </title>
        <link href="https://fonts.googleapis.com/css?family=Sedgwick+Ave+Display" rel="stylesheet">
        <link rel="stylesheet" href='css/font-awesome.min.css'>
        <link rel="stylesheet" href='css/bootstrap-theme.min.css'>
        <link rel="stylesheet" href='css/bootstrap.min.css'>
        <link rel="stylesheet" href='css/style.css'>
    </head>

    <body>
        <main>
